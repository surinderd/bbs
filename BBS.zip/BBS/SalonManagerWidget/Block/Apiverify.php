<?php
namespace BBS\SalonManagerWidget\Block;
use Magento\Framework\View\Element\Template;

class Apiverify extends Template
{
 protected $_pageFactory;

    protected $_apiverifyFactory;
    public function __construct(
        Template\Context $context,
       \Magento\Framework\View\Result\PageFactory $pageFactory,
        \BBS\SalonManagerWidget\Model\ApiverifyFactory $apiverifyFactory

            ) {



        $this->_pageFactory = $pageFactory;
        $this->_apiverifyFactory = $apiverifyFactory;
        parent::__construct($context);
    }

    public function getAPikey(){
       

$apidata = $this->_apiverifyFactory->create();
        $collection = $apidata->getCollection();

        $collectiondata= $collection->getData();
        $apikey="";

        if(!empty($collectiondata))
        {
                $apikey = $collectiondata[0]['apikey'];

        }

return $apikey;


    }
}