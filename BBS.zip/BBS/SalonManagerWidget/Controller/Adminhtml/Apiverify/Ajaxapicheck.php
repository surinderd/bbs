<?php 
namespace BBS\SalonManagerWidget\Controller\Adminhtml\Apiverify;

use Magento\Backend\App\Action\Context;
 use Magento\Framework\Controller\ResultFactory;


class Ajaxapicheck extends \Magento\Backend\App\Action  
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    protected $_pageFactory;

    protected $_apiverifyFactory;

      protected $_objectManager;


    /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \BBS\SalonManagerWidget\Model\ApiverifyFactory $apiverifyFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager,
            Context $context
    ) {
        $this->_pageFactory = $pageFactory;
        $this->_apiverifyFactory = $apiverifyFactory;
        $this->_objectManager = $objectManager;
        parent::__construct($context);
    }

    public function execute()
    {   
    $apikey = $_REQUEST['apikey'];
    
$date = date('m/d/Y h:i:s a', time());

$apidata = $this->_apiverifyFactory->create();
$collection = $apidata->getCollection();
$collectiondata= $collection->getData();

// check api key
function callAPI($method, $url, $data){
   $curl = curl_init();
   switch ($method){
      case "PUT":
         curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
         if ($data)
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
         break;
      default:
         if ($data)
            $url = sprintf("%s?%s", $url, http_build_query($data));
   }
   // OPTIONS:
   curl_setopt($curl, CURLOPT_URL, $url);
   curl_setopt($curl, CURLOPT_HTTPHEADER, array(
           'Content-Type: application/json',
   ));
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
   // EXECUTE:
   $result = curl_exec($curl);
   if(!$result){die("Connection Failure");}
   curl_close($curl);
   return $result;
}
$data_array =  array("accessKey" => $apikey);
$update_plan = callAPI('PUT', 'https://widgets.api.salonmanager.net/v1/web-access-keys/verify', json_encode($data_array));
$response = json_decode($update_plan, true);

$status = $response['status'];

$jsonenocde = json_encode($response);

if(empty($collectiondata))
{
   if($status !== false)
   {
     $model->setData('apikey', $apikey = $_REQUEST['apikey']);
     $model->setData('responseapi','0');
     $model->setData('create_at',$date);
     $model->setData('responseapi',$jsonenocde);
     $model->setData('verificationkey',$status);
     $model->save();
 }

}

else

{
$model = $this->_objectManager->create('BBS\SalonManagerWidget\Model\Apiverify');

   if($status !== false)
   {
    $ids = $collectiondata[0]['id'];
    $model->setData('id', $apikey = $ids);
    $model->setData('apikey', $apikey = $_REQUEST['apikey']);
     $model->setData('responseapi',$jsonenocde);
     $model->setData('verificationkey',$status);
     $model->setData('create_at',$date);
     $model->save();
}
 }






     echo $jsonenocde;




die(0);
        
    }
}

?>