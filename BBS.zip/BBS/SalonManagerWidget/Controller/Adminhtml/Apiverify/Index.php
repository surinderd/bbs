<?php 
namespace BBS\SalonManagerWidget\Controller\Adminhtml\Apiverify;

use Magento\Backend\App\Action\Context;

class Index extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     */
    public function __construct(
            Context $context
    ) {
        parent::__construct($context);
    }

    public function execute()
    {       


        $resultPage = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_PAGE);
        return  $resultPage;
    }
}

?>