<?php
namespace BBS\SalonManagerWidget\Model;

class Apiverify extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'bbs_api';

	protected $_cacheTag = 'bbs_api';

	protected $_eventPrefix = 'bbs_api';

	protected function _construct()
	{
		$this->_init('BBS\SalonManagerWidget\Model\ResourceModel\Apiverify');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}