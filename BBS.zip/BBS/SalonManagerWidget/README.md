Scope:

This extension is usefull for check api key and display widget in footer.

Installtion:

1. Upload extension in app/code folder of root directory

2 Run the following commands after upload the extension

1) php bin/magento setup:upgarde

2) php bin/magento setup:di:compile

3) php bin/magento setup:static-content:dpeloy en_US en_other language if have

4) php bin/magento cache:clear

5)php bin/magento cache:flush



